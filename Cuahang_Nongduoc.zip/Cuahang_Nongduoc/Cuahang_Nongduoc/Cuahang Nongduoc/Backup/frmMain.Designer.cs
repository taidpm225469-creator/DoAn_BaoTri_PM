﻿namespace CuahangNongduoc
{
    partial class frmMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmMain));
            this.menuStrip = new System.Windows.Forms.MenuStrip();
            this.mnuHeThong = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuThoat = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuHienThi = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuThanhCongCu = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuThanhChucNang = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuQuanLy = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuLyDoChi = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuDonViTinh = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuSanPham = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.mnuKhachHang = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuDaiLy = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuNhaCungCap = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuNghiepVu = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuNhapHang = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuBanHang = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuBanHangKH = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuBanHangDL = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuPhieuChi = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuThanhtoan = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.mnuTonghopDuno = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuBaocao = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuBaocaoSoluongton = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuSoLuongBan = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator5 = new System.Windows.Forms.ToolStripSeparator();
            this.mnuSanphamHethan = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuTuychinh = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuTuychinhThongtin = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuTrogiup = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuTrogiupHuongdan = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuTrogiupLienhe = new System.Windows.Forms.ToolStripMenuItem();
            this.toolSanPham = new System.Windows.Forms.ToolStripButton();
            this.toolKhachHang = new System.Windows.Forms.ToolStripButton();
            this.toolDaiLy = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.toolNhapHang = new System.Windows.Forms.ToolStripButton();
            this.toolBanSi = new System.Windows.Forms.ToolStripButton();
            this.toolBanLe = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator4 = new System.Windows.Forms.ToolStripSeparator();
            this.toolTonKho = new System.Windows.Forms.ToolStripButton();
            this.toolStrip = new System.Windows.Forms.ToolStrip();
            this.toolStripSeparator6 = new System.Windows.Forms.ToolStripSeparator();
            this.toolNhaCungCap = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator7 = new System.Windows.Forms.ToolStripSeparator();
            this.toolPhieuChi = new System.Windows.Forms.ToolStripButton();
            this.toolThanhtoan = new System.Windows.Forms.ToolStripButton();
            this.taskPane = new XPExplorerBar.TaskPane();
            this.expando1 = new XPExplorerBar.Expando();
            this.itemDaiLy = new XPExplorerBar.TaskItem();
            this.itemKhachHang = new XPExplorerBar.TaskItem();
            this.itemSanPham = new XPExplorerBar.TaskItem();
            this.itemNhaCungCap = new XPExplorerBar.TaskItem();
            this.expando2 = new XPExplorerBar.Expando();
            this.itemNhapHang = new XPExplorerBar.TaskItem();
            this.itemBanSi = new XPExplorerBar.TaskItem();
            this.itemBanLe = new XPExplorerBar.TaskItem();
            this.itemThanhToan = new XPExplorerBar.TaskItem();
            this.itemPhieuChi = new XPExplorerBar.TaskItem();
            this.expando3 = new XPExplorerBar.Expando();
            this.itemTonghopDoanhthu = new XPExplorerBar.TaskItem();
            this.itemTonKho = new XPExplorerBar.TaskItem();
            this.taskItem1 = new XPExplorerBar.TaskItem();
            this.menuStrip.SuspendLayout();
            this.toolStrip.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.taskPane)).BeginInit();
            this.taskPane.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.expando1)).BeginInit();
            this.expando1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.expando2)).BeginInit();
            this.expando2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.expando3)).BeginInit();
            this.expando3.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip
            // 
            this.menuStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnuHeThong,
            this.mnuHienThi,
            this.mnuQuanLy,
            this.mnuNghiepVu,
            this.mnuBaocao,
            this.mnuTuychinh,
            this.mnuTrogiup});
            this.menuStrip.Location = new System.Drawing.Point(0, 0);
            this.menuStrip.Name = "menuStrip";
            this.menuStrip.Size = new System.Drawing.Size(796, 24);
            this.menuStrip.TabIndex = 1;
            this.menuStrip.Text = "menuStrip1";
            // 
            // mnuHeThong
            // 
            this.mnuHeThong.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnuThoat});
            this.mnuHeThong.Name = "mnuHeThong";
            this.mnuHeThong.Size = new System.Drawing.Size(69, 20);
            this.mnuHeThong.Text = "Hệ thống";
            // 
            // mnuThoat
            // 
            this.mnuThoat.Image = global::CuahangNongduoc.Properties.Resources.Thoat;
            this.mnuThoat.Name = "mnuThoat";
            this.mnuThoat.Size = new System.Drawing.Size(105, 22);
            this.mnuThoat.Text = "Thoát";
            this.mnuThoat.Click += new System.EventHandler(this.mnuThoat_Click);
            // 
            // mnuHienThi
            // 
            this.mnuHienThi.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnuThanhCongCu,
            this.mnuThanhChucNang});
            this.mnuHienThi.Name = "mnuHienThi";
            this.mnuHienThi.Size = new System.Drawing.Size(61, 20);
            this.mnuHienThi.Text = "Hiển thị";
            // 
            // mnuThanhCongCu
            // 
            this.mnuThanhCongCu.Checked = true;
            this.mnuThanhCongCu.CheckState = System.Windows.Forms.CheckState.Checked;
            this.mnuThanhCongCu.Name = "mnuThanhCongCu";
            this.mnuThanhCongCu.Size = new System.Drawing.Size(167, 22);
            this.mnuThanhCongCu.Text = "Thanh công cụ";
            this.mnuThanhCongCu.Click += new System.EventHandler(this.mnuThanhCongCu_Click);
            // 
            // mnuThanhChucNang
            // 
            this.mnuThanhChucNang.Name = "mnuThanhChucNang";
            this.mnuThanhChucNang.Size = new System.Drawing.Size(167, 22);
            this.mnuThanhChucNang.Text = "Thanh chức năng";
            this.mnuThanhChucNang.Click += new System.EventHandler(this.mnuThanhChucNang_Click);
            // 
            // mnuQuanLy
            // 
            this.mnuQuanLy.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnuLyDoChi,
            this.mnuDonViTinh,
            this.mnuSanPham,
            this.toolStripSeparator2,
            this.mnuKhachHang,
            this.mnuDaiLy,
            this.mnuNhaCungCap});
            this.mnuQuanLy.Name = "mnuQuanLy";
            this.mnuQuanLy.Size = new System.Drawing.Size(60, 20);
            this.mnuQuanLy.Text = "Quản lý";
            // 
            // mnuLyDoChi
            // 
            this.mnuLyDoChi.Image = global::CuahangNongduoc.Properties.Resources.LyDoChi;
            this.mnuLyDoChi.Name = "mnuLyDoChi";
            this.mnuLyDoChi.Size = new System.Drawing.Size(148, 22);
            this.mnuLyDoChi.Text = "Lý do chi";
            this.mnuLyDoChi.Click += new System.EventHandler(this.mnuLyDoChi_Click);
            // 
            // mnuDonViTinh
            // 
            this.mnuDonViTinh.Image = global::CuahangNongduoc.Properties.Resources.DonViTinh;
            this.mnuDonViTinh.Name = "mnuDonViTinh";
            this.mnuDonViTinh.Size = new System.Drawing.Size(148, 22);
            this.mnuDonViTinh.Text = "Đơn vị tính";
            this.mnuDonViTinh.Click += new System.EventHandler(this.mnuDonViTinh_Click);
            // 
            // mnuSanPham
            // 
            this.mnuSanPham.Image = global::CuahangNongduoc.Properties.Resources.SanPham;
            this.mnuSanPham.Name = "mnuSanPham";
            this.mnuSanPham.Size = new System.Drawing.Size(148, 22);
            this.mnuSanPham.Text = "Sản phẩm";
            this.mnuSanPham.Click += new System.EventHandler(this.mnuSanPham_Click);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(145, 6);
            // 
            // mnuKhachHang
            // 
            this.mnuKhachHang.Image = global::CuahangNongduoc.Properties.Resources.KhachHang;
            this.mnuKhachHang.Name = "mnuKhachHang";
            this.mnuKhachHang.Size = new System.Drawing.Size(148, 22);
            this.mnuKhachHang.Text = "Khách hàng";
            this.mnuKhachHang.Click += new System.EventHandler(this.mnuKhachHang_Click);
            // 
            // mnuDaiLy
            // 
            this.mnuDaiLy.Image = global::CuahangNongduoc.Properties.Resources.DaiLy;
            this.mnuDaiLy.Name = "mnuDaiLy";
            this.mnuDaiLy.Size = new System.Drawing.Size(148, 22);
            this.mnuDaiLy.Text = " Đại lý";
            this.mnuDaiLy.Click += new System.EventHandler(this.mnuDaiLy_Click);
            // 
            // mnuNhaCungCap
            // 
            this.mnuNhaCungCap.Image = global::CuahangNongduoc.Properties.Resources.NhaCungCap;
            this.mnuNhaCungCap.Name = "mnuNhaCungCap";
            this.mnuNhaCungCap.Size = new System.Drawing.Size(148, 22);
            this.mnuNhaCungCap.Text = "Nhà cung cấp";
            this.mnuNhaCungCap.Click += new System.EventHandler(this.mnuNhaCungCap_Click);
            // 
            // mnuNghiepVu
            // 
            this.mnuNghiepVu.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnuNhapHang,
            this.mnuBanHang,
            this.mnuPhieuChi,
            this.mnuThanhtoan,
            this.toolStripSeparator1,
            this.mnuTonghopDuno});
            this.mnuNghiepVu.Name = "mnuNghiepVu";
            this.mnuNghiepVu.Size = new System.Drawing.Size(74, 20);
            this.mnuNghiepVu.Text = "Nghiệp vụ";
            // 
            // mnuNhapHang
            // 
            this.mnuNhapHang.Image = global::CuahangNongduoc.Properties.Resources.Phieunhap;
            this.mnuNhapHang.Name = "mnuNhapHang";
            this.mnuNhapHang.Size = new System.Drawing.Size(160, 22);
            this.mnuNhapHang.Text = "Nhập hàng";
            this.mnuNhapHang.Click += new System.EventHandler(this.mnuNhapHang_Click);
            // 
            // mnuBanHang
            // 
            this.mnuBanHang.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnuBanHangKH,
            this.mnuBanHangDL});
            this.mnuBanHang.Name = "mnuBanHang";
            this.mnuBanHang.Size = new System.Drawing.Size(160, 22);
            this.mnuBanHang.Text = "Bán hàng";
            // 
            // mnuBanHangKH
            // 
            this.mnuBanHangKH.Image = global::CuahangNongduoc.Properties.Resources.Banle;
            this.mnuBanHangKH.Name = "mnuBanHangKH";
            this.mnuBanHangKH.Size = new System.Drawing.Size(195, 22);
            this.mnuBanHangKH.Text = "Bán lẽ cho Khách hàng";
            this.mnuBanHangKH.Click += new System.EventHandler(this.mnuBanHangKH_Click);
            // 
            // mnuBanHangDL
            // 
            this.mnuBanHangDL.Image = global::CuahangNongduoc.Properties.Resources.Bansi;
            this.mnuBanHangDL.Name = "mnuBanHangDL";
            this.mnuBanHangDL.Size = new System.Drawing.Size(195, 22);
            this.mnuBanHangDL.Text = "Bán sỉ cho Đại lý";
            this.mnuBanHangDL.Click += new System.EventHandler(this.mnuBanHangDL_Click);
            // 
            // mnuPhieuChi
            // 
            this.mnuPhieuChi.Image = global::CuahangNongduoc.Properties.Resources.PhieuChi;
            this.mnuPhieuChi.Name = "mnuPhieuChi";
            this.mnuPhieuChi.Size = new System.Drawing.Size(160, 22);
            this.mnuPhieuChi.Text = "Phiếu chi";
            this.mnuPhieuChi.Click += new System.EventHandler(this.mnuPhieuChi_Click);
            // 
            // mnuThanhtoan
            // 
            this.mnuThanhtoan.Image = global::CuahangNongduoc.Properties.Resources.Thanhtoan;
            this.mnuThanhtoan.Name = "mnuThanhtoan";
            this.mnuThanhtoan.Size = new System.Drawing.Size(160, 22);
            this.mnuThanhtoan.Text = "Phiếu thu";
            this.mnuThanhtoan.Click += new System.EventHandler(this.mnuThanhtoan_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(157, 6);
            // 
            // mnuTonghopDuno
            // 
            this.mnuTonghopDuno.Image = global::CuahangNongduoc.Properties.Resources.DunoKhachhang;
            this.mnuTonghopDuno.Name = "mnuTonghopDuno";
            this.mnuTonghopDuno.Size = new System.Drawing.Size(160, 22);
            this.mnuTonghopDuno.Text = "Tổng hợp dư nợ";
            this.mnuTonghopDuno.Click += new System.EventHandler(this.mnuTonghopDuno_Click);
            // 
            // mnuBaocao
            // 
            this.mnuBaocao.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnuBaocaoSoluongton,
            this.mnuSoLuongBan,
            this.toolStripSeparator5,
            this.mnuSanphamHethan});
            this.mnuBaocao.Name = "mnuBaocao";
            this.mnuBaocao.Size = new System.Drawing.Size(61, 20);
            this.mnuBaocao.Text = "Báo cáo";
            // 
            // mnuBaocaoSoluongton
            // 
            this.mnuBaocaoSoluongton.Image = global::CuahangNongduoc.Properties.Resources.TonKho;
            this.mnuBaocaoSoluongton.Name = "mnuBaocaoSoluongton";
            this.mnuBaocaoSoluongton.Size = new System.Drawing.Size(170, 22);
            this.mnuBaocaoSoluongton.Text = "Số lượng tồn";
            this.mnuBaocaoSoluongton.Click += new System.EventHandler(this.mnuBaocaoSoluongton_Click);
            // 
            // mnuSoLuongBan
            // 
            this.mnuSoLuongBan.Image = global::CuahangNongduoc.Properties.Resources.Soluongban;
            this.mnuSoLuongBan.Name = "mnuSoLuongBan";
            this.mnuSoLuongBan.Size = new System.Drawing.Size(170, 22);
            this.mnuSoLuongBan.Text = "Số lượng bán";
            this.mnuSoLuongBan.Click += new System.EventHandler(this.mnuSoLuongBan_Click);
            // 
            // toolStripSeparator5
            // 
            this.toolStripSeparator5.Name = "toolStripSeparator5";
            this.toolStripSeparator5.Size = new System.Drawing.Size(167, 6);
            // 
            // mnuSanphamHethan
            // 
            this.mnuSanphamHethan.Image = global::CuahangNongduoc.Properties.Resources.SanPhamHethan;
            this.mnuSanphamHethan.Name = "mnuSanphamHethan";
            this.mnuSanphamHethan.Size = new System.Drawing.Size(170, 22);
            this.mnuSanphamHethan.Text = "Sản phẩm hết hạn";
            this.mnuSanphamHethan.Click += new System.EventHandler(this.mnuSanphamHethan_Click);
            // 
            // mnuTuychinh
            // 
            this.mnuTuychinh.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnuTuychinhThongtin});
            this.mnuTuychinh.Name = "mnuTuychinh";
            this.mnuTuychinh.Size = new System.Drawing.Size(72, 20);
            this.mnuTuychinh.Text = "Tùy chỉnh";
            // 
            // mnuTuychinhThongtin
            // 
            this.mnuTuychinhThongtin.Image = global::CuahangNongduoc.Properties.Resources.info;
            this.mnuTuychinhThongtin.Name = "mnuTuychinhThongtin";
            this.mnuTuychinhThongtin.Size = new System.Drawing.Size(180, 22);
            this.mnuTuychinhThongtin.Text = "Thông tin Cửa hàng";
            this.mnuTuychinhThongtin.Click += new System.EventHandler(this.mnuTuychinhThongtin_Click);
            // 
            // mnuTrogiup
            // 
            this.mnuTrogiup.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnuTrogiupHuongdan,
            this.mnuTrogiupLienhe});
            this.mnuTrogiup.Name = "mnuTrogiup";
            this.mnuTrogiup.Size = new System.Drawing.Size(64, 20);
            this.mnuTrogiup.Text = "Trợ giúp";
            // 
            // mnuTrogiupHuongdan
            // 
            this.mnuTrogiupHuongdan.Image = global::CuahangNongduoc.Properties.Resources.help;
            this.mnuTrogiupHuongdan.Name = "mnuTrogiupHuongdan";
            this.mnuTrogiupHuongdan.ShortcutKeys = System.Windows.Forms.Keys.F1;
            this.mnuTrogiupHuongdan.Size = new System.Drawing.Size(199, 22);
            this.mnuTrogiupHuongdan.Text = "Hướng dẫn sử dụng";
            this.mnuTrogiupHuongdan.Click += new System.EventHandler(this.mnuTrogiupHuongdan_Click);
            // 
            // mnuTrogiupLienhe
            // 
            this.mnuTrogiupLienhe.Image = global::CuahangNongduoc.Properties.Resources.info;
            this.mnuTrogiupLienhe.Name = "mnuTrogiupLienhe";
            this.mnuTrogiupLienhe.Size = new System.Drawing.Size(199, 22);
            this.mnuTrogiupLienhe.Text = "Thông tin liên hệ";
            this.mnuTrogiupLienhe.Click += new System.EventHandler(this.mnuTrogiupLienhe_Click);
            // 
            // toolSanPham
            // 
            this.toolSanPham.Image = global::CuahangNongduoc.Properties.Resources.SanPham;
            this.toolSanPham.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.toolSanPham.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolSanPham.Name = "toolSanPham";
            this.toolSanPham.Size = new System.Drawing.Size(64, 43);
            this.toolSanPham.Text = "Sản phẩm";
            this.toolSanPham.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.toolSanPham.Click += new System.EventHandler(this.mnuSanPham_Click);
            // 
            // toolKhachHang
            // 
            this.toolKhachHang.Image = global::CuahangNongduoc.Properties.Resources.KhachHang;
            this.toolKhachHang.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.toolKhachHang.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolKhachHang.Name = "toolKhachHang";
            this.toolKhachHang.Size = new System.Drawing.Size(74, 43);
            this.toolKhachHang.Text = "Khách hàng";
            this.toolKhachHang.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.toolKhachHang.Click += new System.EventHandler(this.mnuKhachHang_Click);
            // 
            // toolDaiLy
            // 
            this.toolDaiLy.Image = global::CuahangNongduoc.Properties.Resources.DaiLy;
            this.toolDaiLy.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.toolDaiLy.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolDaiLy.Name = "toolDaiLy";
            this.toolDaiLy.Size = new System.Drawing.Size(40, 43);
            this.toolDaiLy.Text = "Đại lý";
            this.toolDaiLy.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.toolDaiLy.Click += new System.EventHandler(this.mnuDaiLy_Click);
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new System.Drawing.Size(6, 46);
            // 
            // toolNhapHang
            // 
            this.toolNhapHang.Image = global::CuahangNongduoc.Properties.Resources.Phieunhap;
            this.toolNhapHang.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.toolNhapHang.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolNhapHang.Name = "toolNhapHang";
            this.toolNhapHang.Size = new System.Drawing.Size(70, 43);
            this.toolNhapHang.Text = "Nhập hàng";
            this.toolNhapHang.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.toolNhapHang.Click += new System.EventHandler(this.mnuNhapHang_Click);
            // 
            // toolBanSi
            // 
            this.toolBanSi.Image = global::CuahangNongduoc.Properties.Resources.Bansi;
            this.toolBanSi.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.toolBanSi.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolBanSi.Name = "toolBanSi";
            this.toolBanSi.Size = new System.Drawing.Size(42, 43);
            this.toolBanSi.Text = "Bán sĩ";
            this.toolBanSi.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.toolBanSi.Click += new System.EventHandler(this.mnuBanHangDL_Click);
            // 
            // toolBanLe
            // 
            this.toolBanLe.Image = global::CuahangNongduoc.Properties.Resources.Banle;
            this.toolBanLe.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.toolBanLe.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolBanLe.Name = "toolBanLe";
            this.toolBanLe.Size = new System.Drawing.Size(43, 43);
            this.toolBanLe.Text = "Bán lẽ";
            this.toolBanLe.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.toolBanLe.Click += new System.EventHandler(this.mnuBanHangKH_Click);
            // 
            // toolStripSeparator4
            // 
            this.toolStripSeparator4.Name = "toolStripSeparator4";
            this.toolStripSeparator4.Size = new System.Drawing.Size(6, 46);
            // 
            // toolTonKho
            // 
            this.toolTonKho.Image = global::CuahangNongduoc.Properties.Resources.TonKho;
            this.toolTonKho.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.toolTonKho.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolTonKho.Name = "toolTonKho";
            this.toolTonKho.Size = new System.Drawing.Size(55, 43);
            this.toolTonKho.Text = "Tồn kho";
            this.toolTonKho.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.toolTonKho.Click += new System.EventHandler(this.mnuBaocaoSoluongton_Click);
            // 
            // toolStrip
            // 
            this.toolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolSanPham,
            this.toolStripSeparator6,
            this.toolNhaCungCap,
            this.toolKhachHang,
            this.toolDaiLy,
            this.toolStripSeparator3,
            this.toolNhapHang,
            this.toolBanSi,
            this.toolBanLe,
            this.toolStripSeparator7,
            this.toolPhieuChi,
            this.toolThanhtoan,
            this.toolStripSeparator4,
            this.toolTonKho});
            this.toolStrip.Location = new System.Drawing.Point(0, 24);
            this.toolStrip.Name = "toolStrip";
            this.toolStrip.Size = new System.Drawing.Size(796, 46);
            this.toolStrip.TabIndex = 2;
            this.toolStrip.Text = "toolStrip1";
            // 
            // toolStripSeparator6
            // 
            this.toolStripSeparator6.Name = "toolStripSeparator6";
            this.toolStripSeparator6.Size = new System.Drawing.Size(6, 46);
            // 
            // toolNhaCungCap
            // 
            this.toolNhaCungCap.Image = global::CuahangNongduoc.Properties.Resources.NhaCungCap;
            this.toolNhaCungCap.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.toolNhaCungCap.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolNhaCungCap.Name = "toolNhaCungCap";
            this.toolNhaCungCap.Size = new System.Drawing.Size(85, 43);
            this.toolNhaCungCap.Text = "Nhà cung cấp";
            this.toolNhaCungCap.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.toolNhaCungCap.Click += new System.EventHandler(this.mnuNhaCungCap_Click);
            // 
            // toolStripSeparator7
            // 
            this.toolStripSeparator7.Name = "toolStripSeparator7";
            this.toolStripSeparator7.Size = new System.Drawing.Size(6, 46);
            // 
            // toolPhieuChi
            // 
            this.toolPhieuChi.Image = global::CuahangNongduoc.Properties.Resources.PhieuChi;
            this.toolPhieuChi.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.toolPhieuChi.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolPhieuChi.Name = "toolPhieuChi";
            this.toolPhieuChi.Size = new System.Drawing.Size(60, 43);
            this.toolPhieuChi.Text = "Phiếu chi";
            this.toolPhieuChi.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.toolPhieuChi.Click += new System.EventHandler(this.mnuPhieuChi_Click);
            // 
            // toolThanhtoan
            // 
            this.toolThanhtoan.Image = global::CuahangNongduoc.Properties.Resources.Thanhtoan;
            this.toolThanhtoan.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.toolThanhtoan.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolThanhtoan.Name = "toolThanhtoan";
            this.toolThanhtoan.Size = new System.Drawing.Size(62, 43);
            this.toolThanhtoan.Text = "Phiếu thu";
            this.toolThanhtoan.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.toolThanhtoan.Click += new System.EventHandler(this.mnuThanhtoan_Click);
            // 
            // taskPane
            // 
            this.taskPane.AutoScrollMargin = new System.Drawing.Size(12, 12);
            this.taskPane.CustomSettings.GradientEndColor = System.Drawing.Color.MediumSeaGreen;
            this.taskPane.CustomSettings.GradientStartColor = System.Drawing.Color.SteelBlue;
            this.taskPane.Dock = System.Windows.Forms.DockStyle.Left;
            this.taskPane.Expandos.AddRange(new XPExplorerBar.Expando[] {
            this.expando1,
            this.expando2,
            this.expando3});
            this.taskPane.Location = new System.Drawing.Point(0, 70);
            this.taskPane.Name = "taskPane";
            this.taskPane.Size = new System.Drawing.Size(193, 506);
            this.taskPane.TabIndex = 11;
            this.taskPane.Text = "taskPane1";
            this.taskPane.Visible = false;
            // 
            // expando1
            // 
            this.expando1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.expando1.CustomHeaderSettings.NormalGradientEndColor = System.Drawing.Color.SteelBlue;
            this.expando1.CustomHeaderSettings.NormalGradientStartColor = System.Drawing.Color.MediumSeaGreen;
            this.expando1.CustomHeaderSettings.NormalTitleColor = System.Drawing.Color.White;
            this.expando1.CustomHeaderSettings.NormalTitleHotColor = System.Drawing.Color.PaleGreen;
            this.expando1.CustomHeaderSettings.TitleGradient = true;
            this.expando1.CustomSettings.NormalBackColor = System.Drawing.Color.White;
            this.expando1.CustomSettings.NormalBorderColor = System.Drawing.Color.Teal;
            this.expando1.ExpandedHeight = 170;
            this.expando1.Font = new System.Drawing.Font("Tahoma", 8.25F);
            this.expando1.Items.AddRange(new System.Windows.Forms.Control[] {
            this.itemDaiLy,
            this.itemKhachHang,
            this.itemSanPham,
            this.itemNhaCungCap});
            this.expando1.Location = new System.Drawing.Point(12, 12);
            this.expando1.Name = "expando1";
            this.expando1.Size = new System.Drawing.Size(169, 170);
            this.expando1.TabIndex = 0;
            this.expando1.Text = "Quản Lý";
            // 
            // itemDaiLy
            // 
            this.itemDaiLy.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.itemDaiLy.BackColor = System.Drawing.Color.Transparent;
            this.itemDaiLy.CustomSettings.HotLinkColor = System.Drawing.Color.PaleGreen;
            this.itemDaiLy.CustomSettings.LinkColor = System.Drawing.Color.Maroon;
            this.itemDaiLy.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Bold);
            this.itemDaiLy.Image = ((System.Drawing.Image)(resources.GetObject("itemDaiLy.Image")));
            this.itemDaiLy.Location = new System.Drawing.Point(4, 80);
            this.itemDaiLy.Name = "itemDaiLy";
            this.itemDaiLy.Size = new System.Drawing.Size(151, 16);
            this.itemDaiLy.TabIndex = 12;
            this.itemDaiLy.Text = "Đại lý";
            this.itemDaiLy.TextAlign = System.Drawing.ContentAlignment.TopLeft;
            this.itemDaiLy.UseVisualStyleBackColor = false;
            this.itemDaiLy.Click += new System.EventHandler(this.mnuDaiLy_Click);
            // 
            // itemKhachHang
            // 
            this.itemKhachHang.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.itemKhachHang.BackColor = System.Drawing.Color.Transparent;
            this.itemKhachHang.CustomSettings.HotLinkColor = System.Drawing.Color.PaleGreen;
            this.itemKhachHang.CustomSettings.LinkColor = System.Drawing.Color.Maroon;
            this.itemKhachHang.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Bold);
            this.itemKhachHang.Image = ((System.Drawing.Image)(resources.GetObject("itemKhachHang.Image")));
            this.itemKhachHang.Location = new System.Drawing.Point(4, 53);
            this.itemKhachHang.Name = "itemKhachHang";
            this.itemKhachHang.Size = new System.Drawing.Size(151, 16);
            this.itemKhachHang.TabIndex = 9;
            this.itemKhachHang.Text = "Khách hàng";
            this.itemKhachHang.TextAlign = System.Drawing.ContentAlignment.TopLeft;
            this.itemKhachHang.UseVisualStyleBackColor = false;
            this.itemKhachHang.Click += new System.EventHandler(this.mnuKhachHang_Click);
            // 
            // itemSanPham
            // 
            this.itemSanPham.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.itemSanPham.BackColor = System.Drawing.Color.Transparent;
            this.itemSanPham.CustomSettings.HotLinkColor = System.Drawing.Color.PaleGreen;
            this.itemSanPham.CustomSettings.LinkColor = System.Drawing.Color.Maroon;
            this.itemSanPham.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Bold);
            this.itemSanPham.Image = ((System.Drawing.Image)(resources.GetObject("itemSanPham.Image")));
            this.itemSanPham.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.itemSanPham.Location = new System.Drawing.Point(4, 26);
            this.itemSanPham.Name = "itemSanPham";
            this.itemSanPham.Size = new System.Drawing.Size(151, 16);
            this.itemSanPham.TabIndex = 8;
            this.itemSanPham.Text = "Sản phẩm";
            this.itemSanPham.TextAlign = System.Drawing.ContentAlignment.TopLeft;
            this.itemSanPham.UseVisualStyleBackColor = false;
            this.itemSanPham.Click += new System.EventHandler(this.mnuSanPham_Click);
            // 
            // itemNhaCungCap
            // 
            this.itemNhaCungCap.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.itemNhaCungCap.BackColor = System.Drawing.Color.Transparent;
            this.itemNhaCungCap.CustomSettings.HotLinkColor = System.Drawing.Color.PaleGreen;
            this.itemNhaCungCap.CustomSettings.LinkColor = System.Drawing.Color.Maroon;
            this.itemNhaCungCap.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Bold);
            this.itemNhaCungCap.Image = ((System.Drawing.Image)(resources.GetObject("itemNhaCungCap.Image")));
            this.itemNhaCungCap.Location = new System.Drawing.Point(4, 107);
            this.itemNhaCungCap.Name = "itemNhaCungCap";
            this.itemNhaCungCap.Size = new System.Drawing.Size(151, 16);
            this.itemNhaCungCap.TabIndex = 13;
            this.itemNhaCungCap.Text = "Nhà cung cấp";
            this.itemNhaCungCap.TextAlign = System.Drawing.ContentAlignment.TopLeft;
            this.itemNhaCungCap.UseVisualStyleBackColor = false;
            this.itemNhaCungCap.Click += new System.EventHandler(this.mnuNhaCungCap_Click);
            // 
            // expando2
            // 
            this.expando2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.expando2.CustomHeaderSettings.NormalGradientEndColor = System.Drawing.Color.SteelBlue;
            this.expando2.CustomHeaderSettings.NormalGradientStartColor = System.Drawing.Color.MediumSeaGreen;
            this.expando2.CustomHeaderSettings.NormalTitleColor = System.Drawing.Color.White;
            this.expando2.CustomHeaderSettings.NormalTitleHotColor = System.Drawing.Color.PaleGreen;
            this.expando2.CustomHeaderSettings.TitleGradient = true;
            this.expando2.CustomSettings.NormalBackColor = System.Drawing.Color.White;
            this.expando2.CustomSettings.NormalBorderColor = System.Drawing.Color.Teal;
            this.expando2.ExpandedHeight = 190;
            this.expando2.Font = new System.Drawing.Font("Tahoma", 8.25F);
            this.expando2.Items.AddRange(new System.Windows.Forms.Control[] {
            this.itemNhapHang,
            this.itemBanSi,
            this.itemBanLe,
            this.itemThanhToan,
            this.itemPhieuChi});
            this.expando2.Location = new System.Drawing.Point(12, 194);
            this.expando2.Name = "expando2";
            this.expando2.Size = new System.Drawing.Size(169, 190);
            this.expando2.TabIndex = 1;
            this.expando2.Text = "Nghiệp vụ";
            // 
            // itemNhapHang
            // 
            this.itemNhapHang.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.itemNhapHang.BackColor = System.Drawing.Color.Transparent;
            this.itemNhapHang.CustomSettings.HotLinkColor = System.Drawing.Color.PaleGreen;
            this.itemNhapHang.CustomSettings.LinkColor = System.Drawing.Color.Maroon;
            this.itemNhapHang.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Bold);
            this.itemNhapHang.Image = ((System.Drawing.Image)(resources.GetObject("itemNhapHang.Image")));
            this.itemNhapHang.Location = new System.Drawing.Point(7, 26);
            this.itemNhapHang.Name = "itemNhapHang";
            this.itemNhapHang.Size = new System.Drawing.Size(162, 16);
            this.itemNhapHang.TabIndex = 5;
            this.itemNhapHang.Text = "Nhập hàng";
            this.itemNhapHang.TextAlign = System.Drawing.ContentAlignment.TopLeft;
            this.itemNhapHang.UseVisualStyleBackColor = false;
            this.itemNhapHang.Click += new System.EventHandler(this.mnuNhapHang_Click);
            // 
            // itemBanSi
            // 
            this.itemBanSi.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.itemBanSi.BackColor = System.Drawing.Color.Transparent;
            this.itemBanSi.CustomSettings.HotLinkColor = System.Drawing.Color.PaleGreen;
            this.itemBanSi.CustomSettings.LinkColor = System.Drawing.Color.Maroon;
            this.itemBanSi.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Bold);
            this.itemBanSi.Image = ((System.Drawing.Image)(resources.GetObject("itemBanSi.Image")));
            this.itemBanSi.Location = new System.Drawing.Point(6, 53);
            this.itemBanSi.Name = "itemBanSi";
            this.itemBanSi.Size = new System.Drawing.Size(162, 16);
            this.itemBanSi.TabIndex = 6;
            this.itemBanSi.Text = "Bán sỉ";
            this.itemBanSi.TextAlign = System.Drawing.ContentAlignment.TopLeft;
            this.itemBanSi.UseVisualStyleBackColor = false;
            this.itemBanSi.Click += new System.EventHandler(this.mnuBanHangDL_Click);
            // 
            // itemBanLe
            // 
            this.itemBanLe.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.itemBanLe.BackColor = System.Drawing.Color.Transparent;
            this.itemBanLe.CustomSettings.HotLinkColor = System.Drawing.Color.PaleGreen;
            this.itemBanLe.CustomSettings.LinkColor = System.Drawing.Color.Maroon;
            this.itemBanLe.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Bold);
            this.itemBanLe.Image = ((System.Drawing.Image)(resources.GetObject("itemBanLe.Image")));
            this.itemBanLe.Location = new System.Drawing.Point(6, 81);
            this.itemBanLe.Name = "itemBanLe";
            this.itemBanLe.Size = new System.Drawing.Size(162, 16);
            this.itemBanLe.TabIndex = 7;
            this.itemBanLe.Text = "Bán lẽ";
            this.itemBanLe.TextAlign = System.Drawing.ContentAlignment.TopLeft;
            this.itemBanLe.UseVisualStyleBackColor = false;
            this.itemBanLe.Click += new System.EventHandler(this.mnuBanHangKH_Click);
            // 
            // itemThanhToan
            // 
            this.itemThanhToan.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.itemThanhToan.BackColor = System.Drawing.Color.Transparent;
            this.itemThanhToan.CustomSettings.HotLinkColor = System.Drawing.Color.PaleGreen;
            this.itemThanhToan.CustomSettings.LinkColor = System.Drawing.Color.Maroon;
            this.itemThanhToan.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Bold);
            this.itemThanhToan.Image = ((System.Drawing.Image)(resources.GetObject("itemThanhToan.Image")));
            this.itemThanhToan.Location = new System.Drawing.Point(6, 108);
            this.itemThanhToan.Name = "itemThanhToan";
            this.itemThanhToan.Size = new System.Drawing.Size(162, 16);
            this.itemThanhToan.TabIndex = 8;
            this.itemThanhToan.Text = "Phiếu thu";
            this.itemThanhToan.TextAlign = System.Drawing.ContentAlignment.TopLeft;
            this.itemThanhToan.UseVisualStyleBackColor = false;
            this.itemThanhToan.Click += new System.EventHandler(this.mnuThanhtoan_Click);
            // 
            // itemPhieuChi
            // 
            this.itemPhieuChi.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.itemPhieuChi.BackColor = System.Drawing.Color.Transparent;
            this.itemPhieuChi.CustomSettings.HotLinkColor = System.Drawing.Color.PaleGreen;
            this.itemPhieuChi.CustomSettings.LinkColor = System.Drawing.Color.Maroon;
            this.itemPhieuChi.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Bold);
            this.itemPhieuChi.Image = ((System.Drawing.Image)(resources.GetObject("itemPhieuChi.Image")));
            this.itemPhieuChi.Location = new System.Drawing.Point(6, 135);
            this.itemPhieuChi.Name = "itemPhieuChi";
            this.itemPhieuChi.Size = new System.Drawing.Size(162, 16);
            this.itemPhieuChi.TabIndex = 9;
            this.itemPhieuChi.Text = "Phiếu chi";
            this.itemPhieuChi.TextAlign = System.Drawing.ContentAlignment.TopLeft;
            this.itemPhieuChi.UseVisualStyleBackColor = false;
            this.itemPhieuChi.Click += new System.EventHandler(this.mnuPhieuChi_Click);
            // 
            // expando3
            // 
            this.expando3.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.expando3.CustomHeaderSettings.NormalGradientEndColor = System.Drawing.Color.SteelBlue;
            this.expando3.CustomHeaderSettings.NormalGradientStartColor = System.Drawing.Color.MediumSeaGreen;
            this.expando3.CustomHeaderSettings.NormalTitleColor = System.Drawing.Color.White;
            this.expando3.CustomHeaderSettings.NormalTitleHotColor = System.Drawing.Color.PaleGreen;
            this.expando3.CustomHeaderSettings.TitleGradient = true;
            this.expando3.CustomSettings.NormalBackColor = System.Drawing.Color.White;
            this.expando3.CustomSettings.NormalBorderColor = System.Drawing.Color.Teal;
            this.expando3.ExpandedHeight = 170;
            this.expando3.Font = new System.Drawing.Font("Tahoma", 8.25F);
            this.expando3.Items.AddRange(new System.Windows.Forms.Control[] {
            this.itemTonghopDoanhthu,
            this.itemTonKho,
            this.taskItem1});
            this.expando3.Location = new System.Drawing.Point(12, 396);
            this.expando3.Name = "expando3";
            this.expando3.Size = new System.Drawing.Size(169, 170);
            this.expando3.TabIndex = 2;
            this.expando3.Text = "Báo cáo";
            // 
            // itemTonghopDoanhthu
            // 
            this.itemTonghopDoanhthu.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.itemTonghopDoanhthu.BackColor = System.Drawing.Color.Transparent;
            this.itemTonghopDoanhthu.CustomSettings.HotLinkColor = System.Drawing.Color.PaleGreen;
            this.itemTonghopDoanhthu.CustomSettings.LinkColor = System.Drawing.Color.Maroon;
            this.itemTonghopDoanhthu.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Bold);
            this.itemTonghopDoanhthu.Image = ((System.Drawing.Image)(resources.GetObject("itemTonghopDoanhthu.Image")));
            this.itemTonghopDoanhthu.Location = new System.Drawing.Point(7, 26);
            this.itemTonghopDoanhthu.Name = "itemTonghopDoanhthu";
            this.itemTonghopDoanhthu.Size = new System.Drawing.Size(162, 16);
            this.itemTonghopDoanhthu.TabIndex = 7;
            this.itemTonghopDoanhthu.Text = "Số lượng bán";
            this.itemTonghopDoanhthu.TextAlign = System.Drawing.ContentAlignment.TopLeft;
            this.itemTonghopDoanhthu.UseVisualStyleBackColor = false;
            this.itemTonghopDoanhthu.Click += new System.EventHandler(this.mnuSoLuongBan_Click);
            // 
            // itemTonKho
            // 
            this.itemTonKho.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.itemTonKho.BackColor = System.Drawing.Color.Transparent;
            this.itemTonKho.CustomSettings.HotLinkColor = System.Drawing.Color.PaleGreen;
            this.itemTonKho.CustomSettings.LinkColor = System.Drawing.Color.Maroon;
            this.itemTonKho.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Bold);
            this.itemTonKho.Image = ((System.Drawing.Image)(resources.GetObject("itemTonKho.Image")));
            this.itemTonKho.Location = new System.Drawing.Point(7, 53);
            this.itemTonKho.Name = "itemTonKho";
            this.itemTonKho.Size = new System.Drawing.Size(162, 16);
            this.itemTonKho.TabIndex = 8;
            this.itemTonKho.Text = "Số lượng tồn";
            this.itemTonKho.TextAlign = System.Drawing.ContentAlignment.TopLeft;
            this.itemTonKho.UseVisualStyleBackColor = false;
            // 
            // taskItem1
            // 
            this.taskItem1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.taskItem1.BackColor = System.Drawing.Color.Transparent;
            this.taskItem1.CustomSettings.HotLinkColor = System.Drawing.Color.PaleGreen;
            this.taskItem1.CustomSettings.LinkColor = System.Drawing.Color.Maroon;
            this.taskItem1.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Bold);
            this.taskItem1.Image = ((System.Drawing.Image)(resources.GetObject("taskItem1.Image")));
            this.taskItem1.Location = new System.Drawing.Point(6, 80);
            this.taskItem1.Name = "taskItem1";
            this.taskItem1.Size = new System.Drawing.Size(162, 16);
            this.taskItem1.TabIndex = 9;
            this.taskItem1.Text = "Sản phẩm hết hạn";
            this.taskItem1.TextAlign = System.Drawing.ContentAlignment.TopLeft;
            this.taskItem1.UseVisualStyleBackColor = false;
            this.taskItem1.Click += new System.EventHandler(this.mnuSanphamHethan_Click);
            // 
            // frmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(796, 576);
            this.Controls.Add(this.taskPane);
            this.Controls.Add(this.toolStrip);
            this.Controls.Add(this.menuStrip);
            this.HelpButton = true;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.IsMdiContainer = true;
            this.MainMenuStrip = this.menuStrip;
            this.Name = "frmMain";
            this.Text = "QUAN LY CUA HANG NONG DUOC";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.frmMain_Load);
            this.menuStrip.ResumeLayout(false);
            this.menuStrip.PerformLayout();
            this.toolStrip.ResumeLayout(false);
            this.toolStrip.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.taskPane)).EndInit();
            this.taskPane.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.expando1)).EndInit();
            this.expando1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.expando2)).EndInit();
            this.expando2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.expando3)).EndInit();
            this.expando3.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip;
        private System.Windows.Forms.ToolStripMenuItem mnuHeThong;
        private System.Windows.Forms.ToolStripMenuItem mnuThoat;
        private System.Windows.Forms.ToolStripMenuItem mnuQuanLy;
        private System.Windows.Forms.ToolStripMenuItem mnuSanPham;
        private System.Windows.Forms.ToolStripMenuItem mnuKhachHang;
        private System.Windows.Forms.ToolStripMenuItem mnuDaiLy;
        private System.Windows.Forms.ToolStripMenuItem mnuNghiepVu;
        private System.Windows.Forms.ToolStripMenuItem mnuBaocao;
        private System.Windows.Forms.ToolStripMenuItem mnuTuychinh;
        private System.Windows.Forms.ToolStripMenuItem mnuTrogiup;
        private System.Windows.Forms.ToolStripMenuItem mnuDonViTinh;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripMenuItem mnuNhapHang;
        private System.Windows.Forms.ToolStripMenuItem mnuBanHang;
        private System.Windows.Forms.ToolStripMenuItem mnuBanHangKH;
        private System.Windows.Forms.ToolStripMenuItem mnuBanHangDL;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripMenuItem mnuTonghopDuno;
        private System.Windows.Forms.ToolStripMenuItem mnuBaocaoSoluongton;
        private System.Windows.Forms.ToolStripMenuItem mnuTuychinhThongtin;
        private System.Windows.Forms.ToolStripMenuItem mnuTrogiupHuongdan;
        private System.Windows.Forms.ToolStripMenuItem mnuTrogiupLienhe;
        private System.Windows.Forms.ToolStripButton toolSanPham;
        private System.Windows.Forms.ToolStripButton toolKhachHang;
        private System.Windows.Forms.ToolStripButton toolDaiLy;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
        private System.Windows.Forms.ToolStripButton toolNhapHang;
        private System.Windows.Forms.ToolStripButton toolBanSi;
        private System.Windows.Forms.ToolStripButton toolBanLe;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator4;
        private System.Windows.Forms.ToolStripButton toolTonKho;
        private System.Windows.Forms.ToolStrip toolStrip;
        private XPExplorerBar.TaskPane taskPane;
        private XPExplorerBar.Expando expando1;
        private XPExplorerBar.TaskItem itemDaiLy;
        private XPExplorerBar.TaskItem itemKhachHang;
        private XPExplorerBar.Expando expando2;
        private XPExplorerBar.TaskItem itemNhapHang;
        private XPExplorerBar.Expando expando3;
        private XPExplorerBar.TaskItem itemTonghopDoanhthu;
        private XPExplorerBar.TaskItem itemBanSi;
        private XPExplorerBar.TaskItem itemBanLe;
        private XPExplorerBar.TaskItem itemTonKho;
        private XPExplorerBar.TaskItem itemSanPham;
        private System.Windows.Forms.ToolStripMenuItem mnuHienThi;
        private System.Windows.Forms.ToolStripMenuItem mnuThanhCongCu;
        private System.Windows.Forms.ToolStripMenuItem mnuThanhChucNang;
        private System.Windows.Forms.ToolStripMenuItem mnuThanhtoan;
        private System.Windows.Forms.ToolStripButton toolThanhtoan;
        private XPExplorerBar.TaskItem itemThanhToan;
        private System.Windows.Forms.ToolStripMenuItem mnuSoLuongBan;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator5;
        private System.Windows.Forms.ToolStripMenuItem mnuSanphamHethan;
        private System.Windows.Forms.ToolStripButton toolNhaCungCap;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator6;
        private XPExplorerBar.TaskItem itemNhaCungCap;
        private System.Windows.Forms.ToolStripMenuItem mnuNhaCungCap;
        private System.Windows.Forms.ToolStripMenuItem mnuLyDoChi;
        private System.Windows.Forms.ToolStripMenuItem mnuPhieuChi;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator7;
        private System.Windows.Forms.ToolStripButton toolPhieuChi;
        private XPExplorerBar.TaskItem itemPhieuChi;
        private XPExplorerBar.TaskItem taskItem1;
    }
}