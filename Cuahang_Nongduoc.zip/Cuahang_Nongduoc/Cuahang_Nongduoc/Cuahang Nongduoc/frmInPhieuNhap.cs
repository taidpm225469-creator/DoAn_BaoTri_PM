using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace CuahangNongduoc
{
    public partial class frmInPhieuNhap : Form
    {
        CuahangNongduoc.BusinessObject.PhieuNhap m_PhieuNhap = null;
        public frmInPhieuNhap(CuahangNongduoc.BusinessObject.PhieuNhap ph)
        {
            m_PhieuNhap = ph;
            InitializeComponent();

            reportViewer.LocalReport.ExecuteReportInCurrentAppDomain(System.Reflection.Assembly.GetExecutingAssembly().Evidence);
            this.reportViewer.LocalReport.SubreportProcessing += new Microsoft.Reporting.WinForms.SubreportProcessingEventHandler(LocalReport_SubreportProcessing);
        }

        void LocalReport_SubreportProcessing(object sender, Microsoft.Reporting.WinForms.SubreportProcessingEventArgs e)
        {
            //Th�m
            var list = new List<object>();

            foreach (var ct in m_PhieuNhap.ChiTiet)
            {
                string tenSP = "";
             
                try
                {
                    tenSP = ct.SanPham.TenSanPham;
                    if (string.IsNullOrEmpty(tenSP) && ct.SanPham != null)
                        tenSP = ct.SanPham.TenSanPham;
                }
                catch { tenSP = ""; }

                list.Add(new
                {
                    Id = ct.Id,
                    SanPham = tenSP,
                    GiaNhap = (long)ct.GiaNhap,
                    SoLuong = ct.SoLuong,
                    ThanhTien = (long)(ct.GiaNhap * ct.SoLuong),
                    NgaySanXuat = ct.NgaySanXuat,
                    NgayHetHan = ct.NgayHetHan,
                    NgayNhap = m_PhieuNhap.NgayNhap,
                    PhieuNhap = new { }
                });
            }

            e.DataSources.Clear();
            e.DataSources.Add(new Microsoft.Reporting.WinForms.ReportDataSource("CuahangNongduoc_BusinessObject_MaSanPham", list));
        }


        private void frmInPhieuNhap_Load(object sender, EventArgs e)
        {
            Num2Str num = new Num2Str();
            IList<Microsoft.Reporting.WinForms.ReportParameter> param = new List<Microsoft.Reporting.WinForms.ReportParameter>();
            CuahangNongduoc.BusinessObject.CuaHang ch = ThamSo.LayCuaHang();
            param.Add(new Microsoft.Reporting.WinForms.ReportParameter("ten_cua_hang", ch.TenCuaHang));
            param.Add(new Microsoft.Reporting.WinForms.ReportParameter("dia_chi", ch.DiaChi));
            param.Add(new Microsoft.Reporting.WinForms.ReportParameter("dien_thoai", ch.DienThoai));
            //Th�m
            param.Add(new Microsoft.Reporting.WinForms.ReportParameter("ten_nha_cung_cap", m_PhieuNhap.NhaCungCap.HoTen));
            param.Add(new Microsoft.Reporting.WinForms.ReportParameter("bang_chu", num.NumberToString(m_PhieuNhap.TongTien.ToString())));

            
            this.reportViewer.LocalReport.SetParameters(param);
            this.PhieuNhapBindingSource.DataSource = m_PhieuNhap;
            this.reportViewer.RefreshReport();
        }
    }
}